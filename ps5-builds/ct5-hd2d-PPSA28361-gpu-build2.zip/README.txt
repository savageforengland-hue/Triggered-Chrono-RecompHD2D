CT5 HD-2D for PS5 - GPU build 2 (PPSA28361)
================================================

New: PlayStation buttons everywhere (no keyboard prompts), and mods.

Install: replace /data/homebrew/PPSA28361 with this folder (keep rom.sfc).

Mods: copy each asset pack into its own folder in /data/ct-recomp/packs/
(FTP or USB). In the menu, Packs: turn packs on and set their order,
Reload packs, or "Dump new art" to save the game's tiles and sprites into
/data/ct-recomp/packs/dump/ for editing on a PC (for your own use only).
