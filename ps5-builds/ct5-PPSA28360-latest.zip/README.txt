CT5 (PPSA28360) - PS5 homebrew title, firmware 13.20

1. Copy the PPSA28360 folder to /data/homebrew/PPSA28360 on the PS5 (FTP or USB).
2. Put your own legally dumped ROM in that folder (see PUT_YOUR_ROM_HERE.txt),
   or in /data/ct-recomp/.
3. Register it with ShadowMountPlus and launch it from the home screen.

Settings, saves and asset packs live in /data/ct-recomp/.
No game data is included.
