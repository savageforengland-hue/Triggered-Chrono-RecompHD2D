CT5 for PS5 - build 12 (software renderer, PPSA28360)
===========================================================

New: PlayStation buttons everywhere (no keyboard prompts). Also has the
save fix and no Fullscreen option. Replace /data/homebrew/PPSA28360 (keep rom.sfc).
